# SPDX-License-Identifier: GPL-3.0-or-later
"""Minimal MCP server (streamable HTTP transport, JSON responses only).

Runs in a background thread and only listens on 127.0.0.1. Every request must
carry a random bearer token. Tool calls are never executed in the HTTP thread:
they are queued as ``Task`` objects and handled on Blender's main thread by
``process_tasks`` (called from a ``bpy.app.timers`` callback).

This module does not import ``bpy`` so it can be tested outside Blender.
"""

import json
import os
import queue
import secrets
import tempfile
import threading
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SERVER_NAME = "blender"
SERVER_VERSION = "1.0.0"
DEFAULT_PROTOCOL = "2025-06-18"
TASK_TIMEOUT = 2 * 60 * 60  # seconds; ask_user and code review wait for the user this long
TOOL_TIMEOUT_MS = TASK_TIMEOUT * 1000   # the CLI's own limit per tool call (default 300 s)

# Returned by a dispatcher when the task is finished later (e.g. after approval).
DEFERRED = object()

TOOLS = [
    {
        "name": "get_scene_info",
        "description": (
            "Detailed overview of the current Blender scene: file, render settings, "
            "mode, selection, collections and all objects with transforms, "
            "modifiers and materials."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_object_info",
        "description": (
            "Detailed information about one object: transforms, dimensions, mesh "
            "statistics, modifiers with settings, materials, custom properties, "
            "camera/light data."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"name": {"type": "string", "description": "Exact object name"}},
            "required": ["name"],
        },
    },
    {
        "name": "get_viewport_screenshot",
        "description": (
            "Screenshot of the 3D viewport as the user currently sees it. Use it to "
            "check the result of your changes visually."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "execute_python",
        "description": (
            "Execute Python code inside the running Blender instance. `bpy`, "
            "`bmesh`, `mathutils` and `math` are pre-imported. Use print() to "
            "return values. The code runs on the main thread with a 3D-viewport "
            "context override and creates one undo step. Depending on the user's "
            "settings the user has to approve the code first; if rejected, ask "
            "the user what they want instead."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to run"},
                "description": {
                    "type": "string",
                    "description": "Short description of what the code does, shown to the user (in the user's language)",
                },
            },
            "required": ["code", "description"],
        },
    },
    {
        "name": "render_preview",
        "description": (
            "Render a quick preview from the scene camera (reduced resolution and samples, "
            "the user's render settings otherwise) and return the image. Use it to judge "
            "lighting, materials and composition as they will look in the final render. "
            "Blocks Blender while rendering, so keep it small."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "max_size": {"type": "integer", "description": "Longest side in pixels (default 800, max 1600)"},
                "samples": {"type": "integer", "description": "Max. samples for Cycles/EEVEE (default 16)"},
                "camera": {"type": "string", "description": "Camera to render from (default: the scene camera)"},
            },
        },
    },
    {
        "name": "remember",
        "description": (
            "Save a durable note to the memory file (Markdown). Use it for lasting preferences "
            "and facts the user tells you (units, style, naming, project goals), not for "
            "temporary details. scope 'project' = this .blend file, 'global' = all projects."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "note": {"type": "string", "description": "One short sentence, in the user's language"},
                "scope": {"type": "string", "enum": ["project", "global"]},
            },
            "required": ["note", "scope"],
        },
    },
    {
        "name": "save_lesson",
        "description": (
            "After you fixed an error (failed code, wrong result the user pointed out), save what you "
            "learned so you avoid it next time. Not for one-off typos."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Short title of the problem, e.g. 'Material color via Principled BSDF'"},
                "rule": {"type": "string", "description": "One sentence: what to do (or avoid) in future"},
                "error": {"type": "string", "description": "The error message or wrong behaviour (short)"},
                "solution": {"type": "string", "description": "What fixed it, with the working code if short"},
            },
            "required": ["title", "rule", "error", "solution"],
        },
    },
    {
        "name": "ask_user",
        "description": (
            "Ask the user a question in the Blender sidebar and wait for the answer. "
            "Use it whenever you need a decision, a preference or missing information "
            "instead of guessing. Offer 2-5 short, concrete options; the user can also "
            "type their own answer. Returns the user's answer as text."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "The question, short and clear, in the user's language"},
                "options": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "2-5 short answer options (a few words each)",
                },
                "multi_select": {
                    "type": "boolean",
                    "description": "True if the user may pick several options",
                },
            },
            "required": ["question"],
        },
    },
]


def text_result(text, error=False):
    return {"content": [{"type": "text", "text": text}], "isError": bool(error)}


class Task:
    """A tool call waiting to be handled on Blender's main thread."""

    live = False   # from the Live Connection: not tied to a chat run

    def __init__(self, name, arguments):
        self.name = name
        self.arguments = arguments or {}
        self.event = threading.Event()
        self.result = None
        self.cancelled = False
        # Filled by the dispatcher for tasks that wait for the user.
        self.code = ""
        self.description = ""
        self.question = ""
        self.options = []
        self.multi_select = False
        self.selected = set()

    @property
    def done(self):
        return self.event.is_set()

    def finish(self, result):
        if not self.event.is_set():
            self.result = result
            self.event.set()


_tasks = queue.Queue()
_server = None
_thread = None
_token = None
_live_token = None      # set while the Live Connection is on (see live.py)
live_state = {"file": "", "version": ""}   # kept current on the main thread, read by /live
live_seen = [0.0]       # time.time() of the last /live request (for the chat's status line)
LIVE_OPS = ("info", "object", "python", "screenshot", "image")

# POST /cad?name=<file>[&folder=<folder>]: a CAD export straight from the browser (Onshape) into a
# folder, with the Live Connection's token. Default folder: "CAD" next to the open .blend file.
CAD_EXTS = (".glb", ".gltf", ".json", ".step", ".stp", ".stl", ".3mf", ".obj", ".png", ".jpg", ".jpeg")
CAD_MAX_BYTES = 1 << 30


def cad_origin_allowed(origin):
    """Browser pages that may send CAD files (Onshape, also company domains of it)."""
    host = urllib.parse.urlparse(origin or "").hostname or ""
    return (origin or "").startswith("https://") and (host == "onshape.com" or host.endswith(".onshape.com"))


def cad_upload_target(name, folder=""):
    """The path an uploaded CAD file is written to. Raises ValueError for names and folders that
    are not allowed (only a file name with a CAD extension, only inside the home folder)."""
    base = str(name or "").strip()
    if not base or "/" in base or "\\" in base or base.startswith("."):
        raise ValueError("name must be a plain file name")
    if not base.lower().endswith(CAD_EXTS):
        raise ValueError("Not a CAD file: %s (allowed: %s)" % (base, ", ".join(CAD_EXTS)))
    if base.lower().endswith(".json") and not base.lower().endswith(".cad.json"):
        raise ValueError("Only sidecars (<name>.cad.json) may be sent as JSON")
    if folder:
        target = os.path.abspath(os.path.expanduser(folder))
    elif live_state.get("file"):
        target = os.path.join(os.path.dirname(live_state["file"]), "CAD")
    else:
        target = os.path.expanduser("~/Downloads/CAD")
    home = os.path.realpath(os.path.expanduser("~"))
    real = os.path.realpath(target)
    if not (real == home or real.startswith(home + os.sep)):
        raise ValueError("The folder must be inside your home folder")
    # Not into settings: hidden folders (~/.config, ~/.claude …) and ~/Library (app settings).
    inside = os.path.relpath(real, home).split(os.sep)
    if any(part.startswith(".") and part != "." for part in inside) or inside[0] == "Library":
        raise ValueError("Not into hidden folders or ~/Library")
    return os.path.join(target, base)


def live_token():
    return _live_token


def set_live_token(value):
    global _live_token
    _live_token = value


def is_running():
    return _server is not None


def port():
    return _server.server_address[1] if _server else None


def token():
    return _token


def mcp_config():
    """Config dict for ``claude --mcp-config``."""
    return {
        "mcpServers": {
            SERVER_NAME: {
                "type": "http",
                "url": f"http://127.0.0.1:{port()}/mcp",
                "headers": {"Authorization": f"Bearer {_token}"},
                "timeout": TOOL_TIMEOUT_MS,
            }
        }
    }


def start(port_number=0):
    global _server, _thread, _token
    if _server:
        return
    _token = secrets.token_urlsafe(32)
    _server = ThreadingHTTPServer(("127.0.0.1", port_number), _Handler)
    _server.daemon_threads = True
    _thread = threading.Thread(target=_server.serve_forever, name="claude-mcp", daemon=True)
    _thread.start()


def stop():
    global _server, _thread, _token, _live_token
    if _server:
        _server.shutdown()
        _server.server_close()
    _server = None
    _thread = None
    _token = None
    _live_token = None
    # Release anything still waiting.
    while True:
        try:
            task = _tasks.get_nowait()
        except queue.Empty:
            break
        task.finish(text_result("Blender add-on was stopped.", True))


def process_tasks(dispatch):
    """Run queued tool calls. Must be called on Blender's main thread."""
    handled = False
    while True:
        try:
            task = _tasks.get_nowait()
        except queue.Empty:
            return handled
        handled = True
        if task.cancelled:
            continue
        try:
            result = dispatch(task)
        except Exception:
            result = text_result(traceback.format_exc(), True)
        if result is not DEFERRED:
            task.finish(result)


# Tools of other add-ons (see core.extension_tools), set before each run.
extra_tools = []


def all_tools():
    return TOOLS + list(extra_tools)


def _resolve_tool(name):
    """The tool for a (possibly sloppy) name: prefixes, case, '-' vs '_', close matches."""
    tools = {t["name"]: t for t in all_tools()}
    if name in tools:
        return tools[name]
    import difflib
    clean = str(name or "").split("__")[-1].strip().lower().replace("-", "_").replace(" ", "_")
    if clean in tools:
        return tools[clean]
    match = difflib.get_close_matches(clean, list(tools), n=1, cutoff=0.75)
    return tools[match[0]] if match else None


def _coerce_arguments(tool, arguments):
    """Small models pass JSON as a string or numbers as text: fix what the schema makes obvious."""
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments)
        except ValueError:
            return {}
    if not isinstance(arguments, dict):
        return {}
    props = (tool.get("inputSchema") or {}).get("properties") or {}
    out = {}
    for key, value in arguments.items():
        spec = props.get(key) or {}
        kind = spec.get("type")
        if isinstance(value, str):
            if kind in ("object", "array"):
                try:
                    value = json.loads(value)
                except ValueError:
                    pass
            elif kind == "integer":
                try:
                    value = int(float(value))
                except ValueError:
                    pass
            elif kind == "number":
                try:
                    value = float(value)
                except ValueError:
                    pass
            elif kind == "boolean":
                value = value.strip().lower() in ("true", "1", "yes", "ja")
        out[key] = value
    return out


def _call_tool(name, arguments):
    tool = _resolve_tool(name)
    if tool is None:
        return text_result(f"Unknown tool: {name}. Available: " + ", ".join(t["name"] for t in all_tools()), True)
    name = tool["name"]
    arguments = _coerce_arguments(tool, arguments)
    missing = [k for k in (tool.get("inputSchema") or {}).get("required") or [] if k not in arguments]
    if missing:
        return text_result(f"Tool {name}: missing argument(s) {', '.join(missing)}.", True)
    task = Task(name, arguments)
    _tasks.put(task)
    if not task.event.wait(TASK_TIMEOUT):
        task.cancelled = True
        return text_result("Timeout: the user did not respond in time.", True)
    return task.result


def _handle_rpc(msg):
    """Handle one JSON-RPC message. Returns a response dict or None for notifications."""
    if not isinstance(msg, dict):
        return _error(None, -32600, "Invalid request")
    method = msg.get("method")
    msg_id = msg.get("id")
    params = msg.get("params") or {}

    if msg_id is None:  # notification (or a client response) – nothing to answer
        return None

    if method == "initialize":
        return _ok(msg_id, {
            "protocolVersion": params.get("protocolVersion") or DEFAULT_PROTOCOL,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
        })
    if method == "ping":
        return _ok(msg_id, {})
    if method == "tools/list":
        return _ok(msg_id, {"tools": all_tools()})
    if method == "tools/call":
        return _ok(msg_id, _call_tool(params.get("name"), params.get("arguments")))
    if method in ("resources/list", "prompts/list"):
        key = method.split("/")[0]
        return _ok(msg_id, {key: []})
    return _error(msg_id, -32601, f"Method not found: {method}")


def _ok(msg_id, result):
    return {"jsonrpc": "2.0", "id": msg_id, "result": result}


def _error(msg_id, code, message):
    return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": code, "message": message}}


def _handle_live(payload):
    """One /live request (runs in the HTTP thread); the answer is always a JSON object."""
    import time
    live_seen[0] = time.time()
    if not isinstance(payload, dict):
        return {"ok": False, "error": "Expected a JSON object with 'op'."}
    op = payload.get("op")
    if op == "ping":
        return {"ok": True, **live_state}
    if op not in LIVE_OPS:
        return {"ok": False, "error": f"Unknown op: {op}"}
    task = Task("live_" + op, payload)
    task.live = True
    _tasks.put(task)
    if not task.event.wait(TASK_TIMEOUT):
        task.cancelled = True
        return {"ok": False, "error": "Timeout: the user did not respond in time.", "file": live_state["file"]}
    result = task.result
    if "content" in result:     # rejected, or failed before the code ran
        text = "\n".join(c.get("text", "") for c in result["content"])
        return {"ok": False, "error": text, "file": live_state["file"]}
    return result


class _Handler(BaseHTTPRequestHandler):
    server_version = "BlenderClaudeMCP/1.0"

    def log_message(self, fmt, *args):  # keep Blender's console quiet
        pass

    def _authorized(self):
        if self.path.split("?", 1)[0].rstrip("/") != "/mcp":
            self._send(404)
            return False
        expected = f"Bearer {_token}"
        if not _token or not secrets.compare_digest(self.headers.get("Authorization", ""), expected):
            self._send(401)
            return False
        return True

    def _cors(self):
        """CORS headers for /cad when the request comes from an allowed page (else none)."""
        origin = self.headers.get("Origin", "")
        if not self.path.startswith("/cad") or not cad_origin_allowed(origin):
            return {}
        return {"Access-Control-Allow-Origin": origin, "Vary": "Origin",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Authorization, Content-Type",
                "Access-Control-Allow-Private-Network": "true", "Access-Control-Max-Age": "600"}

    def _send(self, status, body=None):
        data = b"" if body is None else json.dumps(body).encode("utf-8")
        try:
            self.send_response(status)
            for key, value in self._cors().items():
                self.send_header(key, value)
            if body is not None:
                self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            if data:
                self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass  # the CLI gave up on this request (e.g. it was stopped)

    def _post_live(self):
        given = self.headers.get("Authorization", "").encode("utf-8")
        if not _live_token:
            self._send(404, {"ok": False, "error": "Live Connection is off."})
        elif not secrets.compare_digest(given, f"Bearer {_live_token}".encode("utf-8")):
            self._send(401, {"ok": False, "error": "Invalid token."})
        else:
            try:
                length = int(self.headers.get("Content-Length") or 0)
                payload = json.loads(self.rfile.read(length) or b"null")
            except ValueError:
                self._send(400, {"ok": False, "error": "Body is not valid JSON."})
                return
            self._send(200, _handle_live(payload))

    def _post_cad(self):
        given = self.headers.get("Authorization", "").encode("utf-8")
        if not _live_token:
            self._send(404, {"ok": False, "error": "Live Connection is off."})
            return
        if not secrets.compare_digest(given, f"Bearer {_live_token}".encode("utf-8")):
            self._send(401, {"ok": False, "error": "Invalid token."})
            return
        query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        try:
            target = cad_upload_target((query.get("name") or [""])[0], (query.get("folder") or [""])[0])
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0 or length > CAD_MAX_BYTES:
                raise ValueError("Body missing or larger than 1 GB")
        except ValueError as exc:
            self._send(400, {"ok": False, "error": str(exc)})
            return
        os.makedirs(os.path.dirname(target), exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(target), prefix=".upload_")
        try:
            with os.fdopen(fd, "wb") as f:
                left = length
                while left > 0:
                    chunk = self.rfile.read(min(left, 1 << 20))
                    if not chunk:
                        raise ValueError("Upload ended early")
                    f.write(chunk)
                    left -= len(chunk)
            os.replace(tmp, target)
        except (OSError, ValueError) as exc:
            if os.path.exists(tmp):
                os.remove(tmp)
            self._send(400, {"ok": False, "error": str(exc)})
            return
        live_seen[0] = __import__("time").time()
        self._send(200, {"ok": True, "path": target, "bytes": length})

    def do_OPTIONS(self):
        if self.path.split("?", 1)[0].rstrip("/") == "/cad" and self._cors():
            self._send(204)
        else:
            self._send(404)

    def do_POST(self):
        route = self.path.split("?", 1)[0].rstrip("/")
        if route == "/live":
            self._post_live()
            return
        if route == "/cad":
            self._post_cad()
            return
        if not self._authorized():
            return
        try:
            length = int(self.headers.get("Content-Length") or 0)
            payload = json.loads(self.rfile.read(length) or b"null")
        except (ValueError, json.JSONDecodeError):
            self._send(400, _error(None, -32700, "Parse error"))
            return

        if isinstance(payload, list):
            responses = [r for r in (_handle_rpc(m) for m in payload) if r is not None]
            self._send(200, responses) if responses else self._send(202)
        else:
            response = _handle_rpc(payload)
            self._send(200, response) if response is not None else self._send(202)

    def do_GET(self):
        # No server-initiated SSE stream.
        if self._authorized():
            self._send(405)

    def do_DELETE(self):
        if self._authorized():
            self._send(200)
