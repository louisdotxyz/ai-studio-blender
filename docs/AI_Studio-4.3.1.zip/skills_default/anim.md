---
title: ANIM
description: Product films: sections, camera moves, the Video Editor
icon: RENDER_ANIMATION
chat: yes
studio_tab: ANIM
---
Product films with AI Studio's tools. Answer briefly. On by itself when the scene has sections or a film
renders (or with its button in the skill row).
Sections = timeline markers "NN Name" (01 Hero, 02 Explosion). A section runs from its marker to the frame
before the next one. Its camera is marker.camera (own camera P_<name>_01 on a pivot, Pass Index = number).
- api.section_add("Hero", frame=None, from_view=False): a new section from this frame with its own camera,
  starting where the active camera is (or the viewport).
- api.section_frames("01 Intro", start=None, length=None, move_keys=True): move / lengthen; everything after
  moves along with its keys. Never move markers by hand when keys exist.
- api.motion_preset(preset, start, end, amount, reverse, replace=True): one move on the camera's pivot.
  TURNTABLE degrees (360) · SWING ± degrees, there and back · PUSH_IN / PULL_OUT % of the distance (60 / 160)
  · CRANE degrees up (reverse: down) · FOCUS start % (needs drop_focus=True if the camera focuses on an
  object: ask first) · FADE_IN / FADE_OUT frames, from black (reverse: white) via exposure · HOLD.
  Default frames = the current section. Keys already there: replace=True removes them in the frames, False
  keeps them; say which you did.
- api.motion_chain("02 Hero", [("PULL_OUT", 24, 140), ("HOLD", 12), ("TURNTABLE", 0, 90)]): steps one after
  the other (frames 0 = to the end). Motion, Orbit, Explosion and the scene's values are in the Animation tab.
- api.key_pose(): the viewport's view as a key at this frame (with the lens).
- Before rendering: api.film_check() lists problems (NO_CAMERA blocks that section; SHARED camera; OUTDATED
  strip) and the time of the next render per section. api.section_proof(section=None) makes a quick
  viewport image per section from its camera (look at the returned files: right camera, framing?).
  api.section_draft(section=None) renders a Workbench draft in seconds straight into the Video Editor.
  api.section_camera(section, own=False, lock=None): own camera for a section, lock it.
- Render: api.section_render(section=None, quality=None, frames=None) (⌘E, or the render button of a
  section in the Video Editor's Studio tab): each section renders its frames in its own process into
  animation/Frames/<section>/, strictly one after the other, always from its marker's camera (a section
  without one is skipped). quality None = by itself: Low Quality first, High Quality once nothing changed;
  sections already in High Quality with nothing changed are skipped. frames=(a, b) renders only those
  frames again (the others stay). No video per section. High Quality renders at full size.
  scene.studio.farm_films = True: High Quality sections go to the Flamenco render farm (Render tab · Render
  Farm); their frames come back into the Video Editor by themselves.
  api.render_status() says what renders (frame, seconds left); studio_render_queue 'wait' answers only
  when the films are done. Never start own background renders to check a film.
- The Video Editor of the same scene shows every section as an image strip (they come in and fill in by
  themselves; the scene renders 3D, render.use_sequencer stays off). api.cut_build({"01 Intro": ("CROSS",
  12, 0), "02 Hero": ("BLACK", 8, 24)}) sets the transition into the next section, its frames and hold
  frames, and builds the strips again (ours are replaced, the user's own stay). Music + BPM:
  scene.studio.cut_music / cut_bpm, studio.cut(action='SNAP') puts sections on whole beats (ask first, it
  moves keys). api.cut_export(edl=False, format=None, quality=None, size=None, range=None, music=None,
  name=None) renders all strips at the end (animation/Export): format MP4 / H265 / PRORES / WEBM / PNG.
- In the timeline every section strip has a band: green High Quality, orange Low Quality, grey draft, red
  not rendered yet (the strip shows the nearest rendered frame there).
- Explosion view (Animation tab): api.explode_group("Lampenkopf", [parts]) gives a handle "Griff | Lampenkopf";
  the parts follow it only while scene["Explosion"] > 0 (0 = exactly as in CAD). Place groups by moving /
  turning their handles with the explosion open, never the parts themselves. api.explode_arrange(names,
  flat, upright, in_row) turns groups flat to the camera and puts them in a row; api.explode_key_section("02
  Explosion") keys it open in that section and closed after it; api.realign_hooks() after new origins.
