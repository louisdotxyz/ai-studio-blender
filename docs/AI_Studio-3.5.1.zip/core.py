# SPDX-License-Identifier: GPL-3.0-or-later
"""Chat state, main-thread timer and tool dispatch (chat history: chats.py, versions and approval: versions.py)."""

import base64
import json
import os
import queue
import re
import sys
import tempfile
import threading
import time
import traceback
import uuid

import bpy

from . import attachments as att_mod
from . import autosave, blender_tools, claude_cli, lessons, lmstudio, mcp_server, memory, skills
from .i18n import tr
from .preferences import get_prefs

TIMER_INTERVAL = 0.1
MAX_SAVED_CHATS = 50

SYSTEM_PROMPT = """\
You are a Blender {version} assistant in the sidebar of the 3D viewport. You change the user's scene \
directly with the tools of the MCP server "blender":
- execute_python(code, description): run bpy code in the running Blender; one undo step per call. \
bpy, bmesh, math, mathutils (Vector, Matrix, Euler), os, sys, re, json, time, np are imported. \
Plain values (numbers, strings, lists, vectors) and your functions stay for the next call of this chat; \
Blender data (objects, materials) does not: look it up again by name. print() returns values to you. \
Skill helpers are predefined: T (checks), M (photo match), V (render variants), api (AI Studio). \
Never call bpy.ops.render.render yourself (it freezes Blender): use render_preview or the render queue.
- get_scene_info / get_object_info(name): inspect the scene or one object in detail.
- get_viewport_screenshot: see the viewport as the user sees it. render_preview(camera): quick camera render.
- ask_user(question, options): ask with answer buttons. remember(note, scope): save a lasting preference.
- save_lesson(title, rule, error, solution): after fixing an error, record what worked.
- Tools of other add-ons may follow (e.g. studio_* from AI Studio). For their tasks use them \
instead of writing code.

Pitfalls from earlier errors (Blender {version}):
- Blender data never survives a call: get objects, collections, materials, the depsgraph and BVH/KD trees \
again by name in every call, also inside your helper functions from earlier calls (pass names, not \
objects). After a failed call, define its values again. After a join, the joined-away objects are gone.
- Never use C, D, T, M, V, api or np as your own names (they are predefined).
- Several scenes: api.sync_scenes() copies look, the scene's own properties and light values into the \
others; api.copy_scene("present") copies a scene with a word instead of ".001". CAD: api.cad_rules([...]) \
keeps rules in the file (part name regex → material, empty), every import applies them. A big archive: \
api.archive_overview(), api.export_archive(names, remove=True) (ask first). api.light_link(light, targets) \
makes nested collections flat; api.material_slider(name, materials, "Roughness") makes one slider for many.
- Since 3.0 the add-on's data is scene.studio, obj.studio_camera, obj.studio_light, bpy.ops.studio.* \
(older notes and skills may say render_studio: that name is gone).
- Geometry Nodes modifier inputs: getattr(mod.properties.inputs, item.identifier) with the identifiers \
from mod.node_group.interface.items_tree – not mod["Socket_2"]. Several data blocks: \
bpy.data.batch_remove(list). Annotations: scene.annotation / bpy.data.annotations. obj.hide_get(view_layer=vl) \
only with the keyword.
- scene.ray_cast's face index is of the evaluated mesh: use obj.evaluated_get(depsgraph).data for it.
- node_tree.links.new(from_socket, to_socket): sockets (node.outputs[0]), never nodes.
- Never assume a scene ("Scene") or a collection exists: get it and check for None; collections also hold \
other object types (filter o.type == 'LIGHT').
- No scipy in Blender (use mathutils.kdtree or numpy). mesh.vertices[::5] fails: foreach_get into numpy.

How to work:
- Act, don't explain how. For a change, call execute_python right away; don't paste code into the chat.
- Small, focused steps. After visible changes, check the result (screenshot, or print values).
- Prefer bpy.data and direct property access over bpy.ops. Reuse existing materials/objects \
instead of creating duplicates. Never delete or overwrite user data or files without asking.
- Names: cameras P_ (perspective) or O_ (orthographic), lights A_ (area), P_ (point), S_ (spot) or D_ (sun), \
then what they show or do in lower case, then a two-digit number: "P_side_01", "O_front_01", "A_key_01". \
api.rename(obj, "side") names a camera or light that way (the letter from its type, the next free number). \
Other new objects: short and plain with a number, api.unique_name("Deckel") gives "Deckel_01". Never \
Blender's ".001", never a collection prefix. Every scene has exactly these collections: Camera, Set (room, \
floor, props), Light, Object (the product), Archiv (replaced objects), TEMP (your helpers). Put new things \
into the fitting one; never make other top-level collections.
- Objects you replace or that are no longer wanted: api.archive(objects) moves them into the hidden \
archive collection, where the user deletes them. Delete objects only when the user says so explicitly.
- Helper objects (cutters, measuring planes, test objects): put them into api.temp_collection(); it is \
deleted after your answer. Nothing the user should keep goes there.
- CAD models: import every CAD export with studio_cad_import (in code: api.cad_import(path)); it reads \
the sidecar <name>.cad.json, takes a new version over from the old one (materials, collections, modifiers; \
old parts into the archive) and checks the sizes against the CAD. Objects with obj["cad_id"] come from CAD: \
don't fix their geometry in Blender, note the problem for the CAD side with studio_cad_feedback.
- Reference images: api.references() lists the topics in the project's reference folder, \
api.references("CMF") the image paths of one topic (e.g. "reference CMF"); look at them with Read.
- If something is unclear or there are real alternatives, call ask_user (one question, 2-5 short options) \
instead of guessing or asking in plain text.

Context in user messages (added automatically, not typed by the user):
- [Blender context] = current scene state; [Selection] = selected objects – "this/these/die Auswahl" \
means them. "[… unchanged]" = same as before; "[… only changes]" lists just the objects that changed, \
all others are as last described.
- [Skill: …] = task instructions picked by the user; follow them. [Note] = info from the add-on, e.g. undone steps.
- [Attachment: name – path] = attached file; import non-image files with execute_python via the path.
- The user may send more messages while you work; take them into account.

Answers: the panel is narrow plain text. Be brief: 1-3 sentences on what you did or found, no markdown \
tables or headings. Reply in the language of the user's latest message (also tool descriptions and \
ask_user questions/options).
If your answer changed the scene, end it with one extra last line "Version: <one word>" naming the \
change in the user's language (e.g. "Version: Beize"). The add-on shows it as the version name.
"""

LOCAL_PREFIX = """\
Use the tools by calling them, never by writing JSON or code in your answer. Call one tool at a time \
and wait for its result. Run each change only once.
Screenshots are slow on this computer: check results by printing values in execute_python; take a \
screenshot only when the user asks about the look or you really need to see it.
Never open windows, editors, dialogs or renders with a window (no window_new, no 'INVOKE_DEFAULT').

"""

# Chat state (module level).
messages = []        # {"role": "user"|"assistant"|"tool"|"error"|"info", "text": str, "attachments": [...]}
pending = []         # mcp_server.Task objects waiting for code approval
active_skills = []   # checked skills (names); they stay checked until unchecked
_skills_sent = set() # skills whose instructions were already sent in this chat
notes = []           # hints for Claude added to the next message (e.g. undone steps)
_step = 0            # last undo marker used for Claude's code steps
history_rev = 0      # bumped when old messages change (undo, step links)
questions = []       # mcp_server.Task objects from ask_user waiting for an answer
queued = []          # user messages sent while Claude works, answered after the current turn
chat_queue = []      # whole new chats waiting for the current one: {"text", "skills", "attachments", "id"}
queue_hold = {"id": None, "until": 0.0}   # the waiting chat being edited (does not start meanwhile)
connectors_next = set()   # claude.ai connectors (e.g. "Krea") the next run may use, see request_connector
chat_queue_paused = [False]   # stopped by hand: the queue waits until the user goes on
attachments = []     # attachments for the next message (dicts from attachments.make)
session_id = None
current_run = None
streaming_text = ""
usage = {}           # last rate_limit_info from the CLI (+ "updated")
_events = queue.Queue()
_prompt_queue = []   # prompts from the UI, sent by the timer
_followups = []      # (content, uid) to send once the current process has ended
_dirty = True
_started = 0.0
_chats = None
tick_hooks = []      # UI callbacks run on every timer tick
_screenshot_warned = False
pending_title = ""    # name typed for a chat that has no id yet
# What the model is doing right now (shown in the chat while it works).
activity = {"kind": "idle", "detail": "", "chars": 0, "since": 0.0}
context = {"used": 0, "window": 0}  # tokens in the current chat / context window of the model
compacting = False   # a /compact run is active
lessons_count = 0    # lessons of the current model (shown in the sidebar)
_turn = {"start": 0.0, "util": None, "code_calls": 0}  # for the per-answer statistics
COMPACT_COMMAND = "/compact"
_last_sent = {}      # kind -> hash of the context last sent in this session (to skip repeats)
login_needed = False  # the CLI's login is missing or expired (the panel shows a Log in button)
_login_opened = False  # the login window was opened once on its own already
_login_check = {"thread": None, "result": None, "next": 0.0}  # background `claude auth status`
LOGIN_POLL = 3.0      # seconds between checks while logged out and the login window is open
LOGIN_FAST = 600.0    # check that often for this long after the login window opened
_login_since = [0.0]  # when the login window was opened last
login_ok = False      # logged in for sure (status check or a good answer)
update_needed = False  # the CLI is too old for the add-on's options
local_down = False    # LM Studio did not answer
_live_waiting = []    # Live Connection code waiting until the chat's answer is done
_setup_cache = {"time": -10.0, "state": None}


def mark_dirty():
    global _dirty
    _dirty = True


def add_message(role, text, **extra):
    text = (text or "").strip()
    if not text and not extra.get("attachments"):
        return
    # Merge consecutive assistant text chunks into one block.
    if role == "assistant" and messages and messages[-1]["role"] == "assistant":
        messages[-1]["text"] += "\n\n" + text
    else:
        messages.append({"role": role, "text": text, **extra})
    mark_dirty()


def is_busy():
    return current_run is not None


def elapsed():
    return int(time.monotonic() - _started) if current_run else 0


def workdir():
    try:
        path = bpy.utils.extension_path_user(__package__, path="", create=True)
    except Exception:
        path = os.path.join(tempfile.gettempdir(), "claude_blender")
    os.makedirs(path, exist_ok=True)
    return path


def _write_json(name, data):
    path = os.path.join(workdir(), name)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, path)


def _read_json(name, default):
    try:
        with open(os.path.join(workdir(), name), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


# ---------------------------------------------------------------------------
# Attachments

def add_attachment(path):
    att = att_mod.make(path)
    if any(a["path"] == att["path"] for a in attachments):
        return att
    attachments.append(att)
    mark_dirty()
    return att


def remove_attachment(index):
    if 0 <= index < len(attachments):
        attachments.pop(index)
        mark_dirty()


# ---------------------------------------------------------------------------
# Sending

def queue_prompt(text, skill_names=()):
    """Called from UI code (main thread). Answers an open question or queues a message
    (with extra skills, e.g. from a Studio tab).

    The actual send happens in the timer, with a clean context for the screenshot.
    """
    text = (text or "").strip()
    if questions and text and not attachments and not skill_names:
        answer_question(0, text)
        return True
    if not text and not attachments:
        return False
    _prompt_queue.append((text, list(skill_names)))
    return True


# ---------------------------------------------------------------------------
# Chat queue: a message that becomes a new chat once the current chat is done. It keeps the skills
# that were checked and the attachments it had when it was queued; the queue survives a restart.

CHAT_QUEUE_FILE = "chat_queue.json"
QUEUE_PAUSE = 2.0      # seconds between the end of a chat and the start of the next one
_queue_ready = [0.0]


def _save_chat_queue():
    _write_json(CHAT_QUEUE_FILE, {"chats": chat_queue, "paused": chat_queue_paused[0]})


def load_chat_queue():
    data = _read_json(CHAT_QUEUE_FILE, {})
    chats = data.get("chats") if isinstance(data, dict) else None
    chat_queue[:] = [c for c in (chats or []) if isinstance(c, dict) and (c.get("text") or c.get("attachments"))]
    chat_queue_paused[0] = bool(data.get("paused")) if isinstance(data, dict) else False


def queue_chat(text, skill_names=None, connectors=()):
    """Queues `text` as a new chat for after the current one, with the skills checked now (and one named
    with /skill at the start) and the attachments of the message box. connectors: claude.ai connectors
    that chat may use (see request_connector). Returns False for an empty message."""
    text = (text or "").strip()
    if not text and not attachments:
        return False
    names = list(active_skills) if skill_names is None else list(skill_names)
    name, rest = skills.split_command(text)
    if name and skills.find(workdir(), name):
        text = rest
        names.append(skills.find(workdir(), name)["name"])
    chat_queue.append({"id": str(uuid.uuid4()), "text": text, "skills": list(dict.fromkeys(names)),
                       "attachments": [dict(a) for a in attachments], "connectors": list(connectors)})
    attachments.clear()
    _queue_ready[0] = 0.0
    _save_chat_queue()
    mark_dirty()
    return True


def remove_queued_chat(chat_id):
    chat_queue[:] = [c for c in chat_queue if c.get("id") != chat_id]
    _save_chat_queue()
    mark_dirty()


def queued_chat(chat_id):
    return next((c for c in chat_queue if c.get("id") == chat_id), None)


def edit_queued_chat(chat_id, text, keep_files=None, keep_skills=None):
    """Changes a waiting chat: its text, and which of its files and skills it keeps (lists of booleans, in
    order). False when it is not waiting any more (already started or removed)."""
    entry = queued_chat(chat_id)
    if entry is None:
        return False
    text = (text or "").strip()
    files = [a for i, a in enumerate(entry.get("attachments") or [])
             if keep_files is None or (i < len(keep_files) and keep_files[i])]
    if not text and not files:
        remove_queued_chat(chat_id)
        return True
    entry["text"] = text
    entry["attachments"] = files
    entry["skills"] = [s for i, s in enumerate(entry.get("skills") or [])
                       if keep_skills is None or (i < len(keep_skills) and keep_skills[i])]
    _save_chat_queue()
    mark_dirty()
    return True


def move_queued_chat(chat_id, step):
    """Moves a waiting chat earlier (step −1) or later (+1) in the queue."""
    index = next((i for i, c in enumerate(chat_queue) if c.get("id") == chat_id), None)
    if index is None:
        return
    target = max(0, min(len(chat_queue) - 1, index + step))
    chat_queue.insert(target, chat_queue.pop(index))
    _save_chat_queue()
    mark_dirty()


def hold_queued_chat(chat_id):
    """While a waiting chat is being edited it does not start (at most two minutes); None lets it go."""
    queue_hold.update(id=chat_id, until=time.monotonic() + 120.0 if chat_id else 0.0)


def set_chat_queue_paused(paused):
    chat_queue_paused[0] = bool(paused)
    _queue_ready[0] = 0.0
    _save_chat_queue()
    mark_dirty()


def _next_queued_chat():
    """Starts the next queued chat when nothing else is going on (run from the timer)."""
    if not chat_queue or chat_queue_paused[0] or is_busy() or _prompt_queue or questions or pending:
        _queue_ready[0] = 0.0
        return
    if queue_hold.get("id") == chat_queue[0].get("id") and time.monotonic() < queue_hold.get("until", 0.0):
        return                      # the next one is open for editing
    now = time.monotonic()
    if not _queue_ready[0]:
        _queue_ready[0] = now + QUEUE_PAUSE
        return
    if now < _queue_ready[0]:
        return
    _queue_ready[0] = 0.0
    entry = chat_queue.pop(0)
    _save_chat_queue()
    from . import chats
    chats.new_chat()
    attachments[:] = [a for a in entry.get("attachments") or [] if os.path.exists(a.get("path", ""))]
    keep = list(active_skills)
    active_skills[:] = []          # only the skills the message had when it was queued
    for name in entry.get("connectors") or ():
        request_connector(name)
    try:
        _send(entry.get("text", ""), entry.get("skills") or ())
    finally:
        active_skills[:] = keep
    mark_dirty()


def request_connector(name):
    """The next run of the chat may use this claude.ai connector of the user's account (e.g. "Krea": billed to
    the user's own Krea plan). A run that is already going gets it with the next message after it ends."""
    connectors_next.add(name)


# Wishes sent from a Studio tab: tab -> index in `messages` where its answer starts.
studio_prompts = {}


def studio_prompt(tab, text):
    """Send a wish typed in a Studio tab (Render, Light, Material) with that tab's skills."""
    names = [s["name"] for s in skills.list_skills(workdir()) if s.get("studio_tab") == tab]
    if not queue_prompt(text, names):
        return False
    studio_prompts[tab] = len(messages)
    return True


def studio_reply(tab):
    """("working" | "done", first line of the answer) for the last wish from `tab`, or (None, "")."""
    start = studio_prompts.get(tab)
    if start is None or start > len(messages):
        return None, ""
    answer = next((m for m in reversed(messages[start:]) if m["role"] == "assistant"), None)
    if is_busy():
        return "working", activity_text()
    if answer is None:
        return None, ""
    line = next((l for l in plain_text(answer["text"]).splitlines()
                 if l.strip() and not l.startswith("Version:")), "")
    return "done", line.strip()


def is_local(prefs=None):
    prefs = prefs or get_prefs()
    return bool(prefs and prefs.backend == 'LOCAL')


# ---------------------------------------------------------------------------
# Tools from other add-ons
#
# Any add-on can offer tools to the chat with a module named "claude_tools" that has
#     def get_tools():  return [{"name": "studio_light_setup", "description": "...",
#                               "inputSchema": {...}, "handler": func, "label": "Set up lights"}]
# handler(arguments: dict) runs on Blender's main thread and returns a text, or a dict
# {"text": str, "image_png": bytes} (an image for the model to look at). Raising an
# exception returns the error to the model. The list is read again before every run.

_ext_tools = {}


def extension_tools():
    tools = []
    for name, module in list(sys.modules.items()):
        if name.endswith(".claude_tools") and name != __name__ and callable(getattr(module, "get_tools", None)):
            try:
                tools.extend(t for t in module.get_tools() if t.get("name") and callable(t.get("handler")))
            except Exception:
                traceback.print_exc()
    return tools


def _refresh_extension_tools():
    _ext_tools.clear()
    builtin = {t["name"] for t in mcp_server.TOOLS}
    for tool in extension_tools():
        if tool["name"] not in builtin:
            _ext_tools[tool["name"]] = tool
    mcp_server.extra_tools[:] = [
        {"name": t["name"], "description": t.get("description", ""),
         "inputSchema": t.get("inputSchema") or {"type": "object", "properties": {}}}
        for t in _ext_tools.values()]


# Tool calls that wait for something (e.g. the render queue) without blocking Blender:
# [(task, check, deadline)]; check() returns None while waiting, else the result text.
_waiting = []
WAIT_LIMIT = 2 * 60 * 60


def _run_extension_tool(tool, args, task=None):
    result = tool["handler"](args or {})
    if isinstance(result, dict) and callable(result.get("wait")) and task is not None:
        set_activity("tool_running", result.get("label") or tr("waiting…"))
        _waiting.append((task, result["wait"], time.monotonic() + WAIT_LIMIT))
        return mcp_server.DEFERRED
    if isinstance(result, dict):
        content = []
        if result.get("text"):
            content.append({"type": "text", "text": str(result["text"])})
        if result.get("image_png"):
            content.append({"type": "image", "mimeType": "image/png",
                            "data": base64.b64encode(result["image_png"]).decode("ascii")})
        return {"content": content or [{"type": "text", "text": "Done."}], "isError": False}
    return mcp_server.text_result(str(result) if result is not None else "Done.")


def model_label(prefs=None):
    """Name of the model in use, for texts like "Sonnet is working"."""
    prefs = prefs or get_prefs()
    if prefs is None:
        return "Claude"
    if is_local(prefs):
        return lmstudio.display_name(prefs.local_model) if prefs.local_model else tr("Local model")
    from .preferences import MODELS
    return next((name for key, name, _d in MODELS if key == prefs.model), "Claude")


def set_activity(kind, detail=""):
    if activity["kind"] != kind or activity["detail"] != detail:
        activity.update(kind=kind, detail=detail, chars=0, since=time.monotonic())
        mark_dirty()


def activity_text():
    """Short description of what the model is doing, e.g. 'writing · 120 tokens · 14 tok/s'."""
    kind, detail = activity["kind"], activity["detail"]
    tokens = activity["chars"] // 4  # rough estimate while streaming
    secs = max(0.1, time.monotonic() - activity["since"])
    rate = f" · {tokens / secs:.0f} tok/s" if tokens > 20 else ""
    if lmstudio.busy():
        return tr("loading the model in LM Studio…")
    if kind == "compacting":
        return tr("summarizing the chat…")
    if kind == "thinking":
        return tr("thinking… {} tokens").format(tokens) + rate
    if kind == "writing":
        return tr("writing… {} tokens").format(tokens) + rate
    if kind == "tool_call":
        if detail == "execute_python":
            return tr("writing code… {} tokens").format(tokens) + rate
        return tr("preparing {}…").format(detail)
    if kind == "tool_running":
        return detail
    if kind == "waiting":
        return tr("waiting for you")
    if kind == "rendering":
        return tr("rendering a preview in the background…")
    if is_local():
        return tr("reading the prompt…")  # prompt processing: the slow part on a local model
    return tr("thinking…")


def context_fraction():
    return context["used"] / context["window"] if context["window"] else 0.0


def _changed(kind, data):
    """True if this context differs from what was last sent in this session."""
    digest = hash(data)
    if session_id and _last_sent.get(kind) == digest:
        return False
    _last_sent[kind] = digest
    return True


def _scene_text(header, objects, total, max_objects):
    """Full scene summary on the first message, afterwards only what changed (saves tokens)."""
    header_text = "\n".join(header)
    previous = _last_sent.get("objects") if session_id else None
    current = dict(objects)
    _last_sent["objects"] = current
    if previous is None:
        lines = [line for _name, line in objects] + blender_tools._more_line(total, max_objects)
        return "[Blender context]\n" + header_text + "\n" + "\n".join(lines)
    changed = [line for name, line in objects if previous.get(name) != line]
    removed = [name for name in previous if name not in current]
    if not changed and not removed:
        if not _changed("scene_header", header_text):
            return "[Blender context unchanged]"
        return "[Blender context – objects unchanged]\n" + header_text
    parts = ["[Blender context – only changes since the last message]", header_text]
    if changed:
        parts.append("Changed or new objects:\n" + "\n".join(changed))
    if removed:
        parts.append("Removed objects: " + ", ".join(removed[:50]))
    return "\n".join(parts)


def model_slug(prefs=None):
    """Folder name for the model's lessons (each model learns separately)."""
    prefs = prefs or get_prefs()
    if prefs is None:
        return "claude"
    if is_local(prefs):
        return lessons.slug(prefs.local_model or "local")
    return "claude-" + prefs.model


def lessons_root(prefs=None):
    prefs = prefs or get_prefs()
    return lessons.project_dir(prefs.lessons_dir if prefs else "", workdir())


def _build_content(text, atts, prefs):
    local = is_local(prefs)
    max_img = prefs.screenshot_max_size if prefs else 1568
    # Automatic screenshots stay in the chat history: keep them small (~800 tokens at 1024 px).
    # On a local model images also cost a lot of prompt processing.
    shot_size = min(max_img, 768 if local else 1024)
    content = []
    if prefs is None or prefs.send_scene_context:
        try:
            max_objects = 25 if local else 80
            with blender_tools.viewport_context():
                header, objects, total = blender_tools.scene_summary_parts(max_objects)
            content.append({"type": "text", "text": _scene_text(header, objects, total, max_objects)})
        except Exception as exc:
            add_message("info", tr("Could not describe the scene: {}").format(exc))
    send_shot = prefs.local_send_screenshot if local else (prefs is not None and prefs.auto_screenshot)
    if local and not lmstudio.has_vision(prefs.local_model):
        send_shot = False
    if send_shot:
        try:
            png = blender_tools.capture_viewport(shot_size)
            if _changed("screenshot", png):
                content.append({"type": "text", "text": "[Viewport screenshot]"})
                content.append({"type": "image", "source": {
                    "type": "base64", "media_type": "image/png",
                    "data": base64.b64encode(png).decode("ascii")}})
            else:
                content.append({"type": "text", "text": "[Viewport unchanged]"})
        except Exception as exc:
            global _screenshot_warned
            if not _screenshot_warned:  # say it once, not with every message
                _screenshot_warned = True
                add_message("info", tr("Viewport screenshot not possible: {}").format(exc))
    wm = bpy.context.window_manager
    if (prefs is None or prefs.send_selection) and getattr(wm, "claude_use_selection", True):
        try:
            info = blender_tools.selection_info(max_objects=3 if local else 5, max_chars=600 if local else 1200)
            if info and _changed("selection", info):
                content.append({"type": "text", "text": "[Selection]\n" + info})
            elif info:
                content.append({"type": "text", "text": "[Selection unchanged]"})
        except Exception:
            traceback.print_exc()
    if notes:
        content.append({"type": "text", "text": "[Note]\n" + "\n".join(notes)})
        notes.clear()
    for att in atts:
        try:
            content.extend(att_mod.content_blocks(att, max_img))
        except Exception as exc:
            add_message("error", tr("Could not read attachment '{}': {}").format(att["name"], exc))
    content.append({"type": "text", "text": text or "(see attachment)"})
    return content


def _send(text, extra_skills=()):
    prefs = get_prefs()
    atts = list(attachments)
    attachments.clear()
    chosen = []
    name, rest = skills.split_command(text)
    if name:
        skill = skills.find(workdir(), name)
        if skill:
            text = rest
            chosen.append(skill)
    for name in list(active_skills):
        skill = skills.find(workdir(), name)
        if skill is None:
            active_skills.remove(name)  # file was deleted
        elif all(s["name"] != skill["name"] for s in chosen):
            chosen.append(skill)
    for name in extra_skills:   # e.g. the skills of the Studio tab the wish came from
        skill = skills.find(workdir(), name)
        if skill and all(s["name"] != skill["name"] for s in chosen):
            chosen.append(skill)
    for skill in skills.auto_for(workdir(), text):   # the message asks for it: on for this message
        if all(s["name"] != skill["name"] for s in chosen):
            chosen.append(skill)
    done_once = [s["name"] for s in chosen if skills.is_once(s) and s["name"] in active_skills]
    if done_once:                # one-off skills (SORT, CAD …) switch themselves off after this message
        active_skills[:] = [n for n in active_skills if n not in done_once]
        skills.save_active(workdir(), active_skills)
    if chosen:
        if not session_id:
            _skills_sent.clear()
        new = [s for s in chosen if s["name"] not in _skills_sent]
        known = [s for s in chosen if s["name"] in _skills_sent]
        prompt = skills.build_multi(new, known, text)
        _skills_sent.update(s["name"] for s in chosen)
    else:
        prompt = text

    msg = {"role": "user", "text": text,
           "attachments": [{"name": a["name"], "kind": a["kind"], "path": a["path"]} for a in atts]}
    if chosen:
        msg["skill"] = ", ".join(s["title"] for s in chosen)
    content = _build_content(prompt, atts, prefs)
    uid = str(uuid.uuid4())

    if current_run is not None:
        # Interjection: same session. Shown as waiting until the CLI picks it up.
        queued.append(dict(msg, uid=uid))
        if not current_run.send(content, uid):
            _followups.append((content, uid))
        mark_dirty()
        return

    messages.append(msg)
    mark_dirty()
    _start_run([(content, uid)], prefs)


def _start_run(outgoing, prefs, single=False):
    global current_run, _started, streaming_text
    local = bool(prefs and prefs.backend == 'LOCAL')
    if local and not prefs.local_model:
        add_message("error", tr("Choose a local model first (LM Studio models in ~/.lmstudio/models)."))
        return
    if not local and not bpy.app.online_access:
        if bpy.app.online_access_override:
            add_message("error", tr("Blender was started offline (--offline-mode), but Claude Code needs "
                                    "the internet. Start Blender without it, or use a local model."))
        else:
            add_message("error", tr("Online access is off in Blender, but Claude Code needs the internet. "
                                    "Click 'Allow' in the setup card below, then send the message again."))
        return
    claude_path = claude_cli.find_claude(prefs.claude_path if prefs else "")
    if not claude_path:
        add_message("error", tr("Claude CLI not found. Install Claude Code and log in once by running "
                                "'claude' in a terminal, or set the path in the add-on preferences."))
        return

    if not mcp_server.is_running():
        mcp_server.start()
    _refresh_extension_tools()

    config_path = os.path.join(workdir(), "mcp_config.json")
    fd = os.open(config_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(mcp_server.mcp_config(), f)

    system_prompt = SYSTEM_PROMPT.format(version=bpy.app.version_string)
    if local:
        system_prompt = LOCAL_PREFIX + system_prompt
    if prefs and prefs.custom_instructions.strip():
        system_prompt += "\nAdditional instructions from the user:\n" + prefs.custom_instructions.strip()
    system_prompt += memory.system_prompt_section(workdir())
    if prefs and prefs.learn_from_errors:
        try:
            global lessons_count
            lessons_count = lessons.count(lessons_root(prefs), model_slug(prefs))
            system_prompt += lessons.prompt_section(lessons_root(prefs), model_slug(prefs),
                                                    max_chars=1000 if local else 2000)
        except OSError:
            traceback.print_exc()

    if local:
        model, wanted, effort = prefs.local_model, prefs.local_context, prefs.local_effort

        def prepare(run):  # in the CLI thread: load the model, then size the context to it
            ctx, error = lmstudio.prepare(model, wanted)
            if not error:
                run.env.update(lmstudio.env(model, ctx, effort))
            return error

        kwargs = dict(model=model, env_extra=lmstudio.env(model, wanted, effort), prepare=prepare,
                      local_args=lmstudio.cli_args(system_prompt))
        if lmstudio.LOCAL_EFFORTS.get(effort):
            kwargs["effort"] = lmstudio.LOCAL_EFFORTS[effort]
    else:
        kwargs = dict(model=prefs.model if prefs else "", effort=prefs.effort if prefs else "")
    current_run = claude_cli.ClaudeRun(
        claude_path, _events,
        cwd=workdir(),
        mcp_config_path=config_path,
        system_prompt=system_prompt,
        session_id=session_id,
        extra_args=prefs.extra_args if prefs else "",
        single=single,
        connectors=sorted(connectors_next),
        **kwargs,
    )
    connectors_next.clear()
    for content, uid in outgoing:
        current_run.send(content, uid)
    set_activity("loading" if local else "prompt")
    _turn.update(start=time.monotonic(), util=_session_utilization(), code_calls=0)
    streaming_text = ""
    _started = time.monotonic()
    current_run.start()


def _session_utilization():
    window = ((usage or {}).get("unifiedWindows") or {}).get("five_hour") or {}
    value = window.get("utilization")
    if value is None:
        return None
    value = float(value)
    return value / 100 if value > 1.5 else value


def _record_stats(obj):
    """Duration, tokens and usage share of this answer, kept on the last assistant message."""
    prefs = get_prefs()
    if prefs and not prefs.show_stats:
        return
    target = next((m for m in reversed(messages) if m["role"] == "assistant"), None)
    if target is None or target.get("stats"):
        return
    u = obj.get("usage") or {}
    # usage.input_tokens of a result adds up every model call of the turn (cache reads included),
    # so it is not a useful size; show the context the chat has now and what was written.
    tokens_out = int(u.get("output_tokens") or 0)
    secs = int(time.monotonic() - _turn["start"]) if _turn["start"] else int(obj.get("duration_ms", 0) / 1000)
    parts = [f"{secs}s", tr("{} written").format(_k(tokens_out))]
    if context["used"]:
        parts.append(tr("context {}").format(_k(context["used"])))
    if not is_local(prefs):
        after, before = _session_utilization(), _turn.get("util")
        if after is not None and before is not None and after >= before:
            parts.append(tr("session +{:.1f}%").format((after - before) * 100))
    target["stats"] = " · ".join(parts)


def _k(n):
    return f"{n / 1000:.1f}k" if n >= 1000 else str(n)


def _chat_tasks():
    """Open approvals and questions of the chat (the Live Connection's don't end with a run)."""
    return [task for task in pending + questions if not task.live]


def _clear_chat_tasks():
    pending[:] = [task for task in pending if task.live]
    questions.clear()


def stop():
    if current_run:
        current_run.cancel()
    for task in _chat_tasks():
        task.finish(mcp_server.text_result("Cancelled: the user stopped the request.", True))
    _clear_chat_tasks()
    for msg in queued:  # keep what the user wrote
        msg.pop("uid", None)
        messages.append(msg)
    queued.clear()
    _followups.clear()
    mark_dirty()


# ---------------------------------------------------------------------------
# Usage

def load_usage():
    global usage
    usage = _read_json("usage.json", {}) or {}


def _update_usage(info):
    global usage
    if not isinstance(info, dict):
        return
    usage = dict(info, updated=time.time())
    try:
        _write_json("usage.json", usage)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Approval of code

def _run_code_task(task):
    global _step, history_rev
    _step = max(_step, int(bpy.context.scene.get(blender_tools.UNDO_MARKER, 0))) + 1
    prefs = get_prefs()
    _turn["code_calls"] += 1
    autosave.before_risky("before code")
    autosave.note_step(tr("code: {}").format(task.description or "…"))
    output, ok = blender_tools.execute_python(task.code, "Claude: " + (task.description or "Code"), _step,
                                              max_output=3000 if is_local(prefs) else 6000,
                                              chat=_chat_serial[0])
    # Link the step to its action line in the chat (the latest code action without a step).
    for msg in reversed(messages):
        if msg["role"] == "tool" and msg.get("code") and "step" not in msg:
            msg["step"] = _step
            history_rev += 1
            break
    if getattr(task, "from_text", False):  # code the model only wrote: tell it what happened
        notes.append("The user ran the code you wrote in your answer. " + ("Output:\n" if ok else "It failed:\n")
                     + output[-1500:])
    if not ok:
        add_message("error", tr("Code error:") + "\n" + output[-1500:])
        if prefs and prefs.learn_from_errors:
            output += ("\n\n[After you have fixed this error, call save_lesson once with the problem and the "
                       "working solution.]")
    return mcp_server.text_result(output, not ok)


def undo_from(first_step):
    """Undo Claude's code steps from first_step on (main thread, object mode)."""
    global history_rev
    if bpy.context.mode != 'OBJECT':
        return tr("Undo only works in Object Mode.")
    count, problem = blender_tools.undo_claude_steps(first_step)
    if count:
        # Steps newer than the marker that is now in the scene are undone.
        current = int(bpy.context.scene.get(blender_tools.UNDO_MARKER, 0))
        undone = [m for m in messages if m["role"] == "tool" and m.get("step", 0) > current
                  and m.get("step", 0) >= first_step and not m.get("undone")]
        for m in undone:
            m["undone"] = True
        history_rev += 1
        names = ", ".join(m["text"] for m in undone) or tr("Claude's changes")
        add_message("info", tr("Undone: {}").format(names))
        notes.append(f"The user undid your changes: {names}. The scene is back in the state before them.")
    mark_dirty()
    return problem


# ---------------------------------------------------------------------------
# Questions from Claude (ask_user)

def toggle_option(index, option):
    if 0 <= index < len(questions):
        task = questions[index]
        task.selected ^= {option}
        mark_dirty()


def answer_question(index, answer):
    if not 0 <= index < len(questions):
        return
    task = questions.pop(index)
    answer = (answer or "").strip()
    if task.done:
        return
    add_message("question", task.question)
    add_message("user", answer or tr("(no answer)"))
    task.finish(mcp_server.text_result(f"The user answered: {answer}" if answer
                                       else "The user did not choose anything."))
    mark_dirty()


# ---------------------------------------------------------------------------
# Tool dispatch (main thread)

def _run_live_code(task):
    autosave.note_step(tr("code: {}").format(task.description or "…"))
    output, ok = blender_tools.execute_python(task.code, "Claude Live", max_output=200000, live=True)
    file = bpy.data.filepath
    return {"ok": True, "output": output, "file": file} if ok else {"ok": False, "error": output, "file": file}


def _dispatch_live(task):
    """A request over the Live Connection (live.py): the answer is the JSON sent back."""
    args = task.arguments
    if task.name == "live_info":
        with blender_tools.viewport_context():
            return {"ok": True, "text": blender_tools.scene_summary(max_objects=200)}
    if task.name == "live_object":
        obj, text = blender_tools.object_info(str(args.get("name", "")))
        return {"ok": True, "text": text} if obj is not None else {"ok": False, "error": text}
    if task.name == "live_screenshot":
        try:
            size = max(64, min(4096, int(args.get("max_size") or 1280)))
            png = blender_tools.capture_viewport(size)
        except Exception as exc:
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        return {"ok": True, "png": base64.b64encode(png).decode("ascii")}
    if task.name == "live_image":
        try:
            png = blender_tools.image_file_png(str(args.get("path", "")), int(args.get("max_size") or 1280))
        except Exception as exc:
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        return {"ok": True, "png": base64.b64encode(png).decode("ascii")}
    task.code = str(args.get("code", ""))
    task.description = str(args.get("description", "")).strip()
    if not task.code.strip():
        return {"ok": False, "error": "Parameter 'code' is required.", "file": bpy.data.filepath}
    if current_run:   # the chat is changing the scene right now: one after the other
        _live_waiting.append(task)
        mark_dirty()
        return mcp_server.DEFERRED
    return _live_python(task)


def _live_python(task):
    prefs = get_prefs()
    if task.description:
        add_message("info", "Cowork: " + task.description)
    if prefs and prefs.auto_approve:
        return _run_live_code(task)
    pending.append(task)
    mark_dirty()
    return mcp_server.DEFERRED


def _dispatch(task):
    if task.live:
        return _dispatch_live(task)
    args = task.arguments
    name = task.name
    prefs = get_prefs()

    if name in _ext_tools:
        tool = _ext_tools[name]
        set_activity("tool_running", tool.get("label") or name)
        try:
            with blender_tools.viewport_context():  # so the add-on's bpy.ops work
                return _run_extension_tool(tool, args, task)
        except Exception as exc:
            add_message("error", tr("Tool error: {}").format(f"{name}: {exc}"))
            return mcp_server.text_result(f"{type(exc).__name__}: {exc}", True)
    set_activity("tool_running", tr(TOOL_LABELS.get(name, name)) if name in TOOL_LABELS else name)
    if name == "get_scene_info":
        with blender_tools.viewport_context():
            return mcp_server.text_result(blender_tools.scene_summary(max_objects=60 if is_local(prefs) else 200))

    if name == "save_lesson":
        if prefs and not prefs.learn_from_errors:
            return mcp_server.text_result("Learning from errors is turned off by the user.")
        try:
            page, new = lessons.save(lessons_root(prefs), model_slug(prefs), model_label(prefs),
                                     str(args.get("title", "")).strip() or "Lesson",
                                     " ".join(str(args.get("rule", "")).split()),
                                     str(args.get("error", "")), str(args.get("solution", "")))
        except OSError as exc:
            return mcp_server.text_result(f"Could not save the lesson: {exc}", True)
        add_message("info", tr("Learned: {}").format(str(args.get("title", "")).strip()))
        global lessons_count
        lessons_count += 1 if new else 0
        return mcp_server.text_result(("Saved" if new else "Updated") + f" lesson '{page}'.")

    if name == "get_object_info":
        obj, text = blender_tools.object_info(str(args.get("name", "")))
        return mcp_server.text_result(text, obj is None)

    if name == "get_viewport_screenshot":
        size = prefs.screenshot_max_size if prefs else 1568
        png = blender_tools.capture_viewport(min(size, 768) if is_local(prefs) else size)
        return {"content": [{"type": "image", "mimeType": "image/png",
                             "data": base64.b64encode(png).decode("ascii")}], "isError": False}

    if name == "render_preview":
        # Rendered by the Studio's render worker: Blender stays usable meanwhile.
        size = max(128, min(1600, int(args.get("max_size") or 800)))
        samples = max(1, min(1024, int(args.get("samples") or 16)))
        scene = bpy.context.scene
        camera = bpy.data.objects.get(args["camera"]) if args.get("camera") else scene.camera
        if camera is None or camera.type != 'CAMERA':
            return mcp_server.text_result(tr("No camera named {}").format(args.get("camera") or ""), True)

        def done(path, error):
            if error:
                task.finish(mcp_server.text_result(error, True))
                return
            with open(path, "rb") as f:
                png = f.read()
            os.remove(path)
            task.finish({"content": [{"type": "image", "mimeType": "image/png",
                                      "data": base64.b64encode(png).decode("ascii")}], "isError": False})
        from .studio import runner as studio_runner
        try:
            studio_runner.request_preview(scene, camera, size, samples, done)
        except Exception as ex:
            return mcp_server.text_result(str(ex), True)
        set_activity("rendering")
        return mcp_server.DEFERRED

    if name == "remember":
        ok, text = memory.remember(workdir(), args.get("note", ""), args.get("scope", "project"))
        if ok:
            add_message("info", tr("Remembered: {}").format(" ".join(str(args.get("note", "")).split())))
        return mcp_server.text_result(text, not ok)

    if name == "ask_user":
        task.question = str(args.get("question", "")).strip()
        opts = args.get("options") or []
        task.options = [str(o).strip() for o in opts if str(o).strip()][:8]
        task.multi_select = bool(args.get("multi_select")) and len(task.options) > 1
        if not task.question:
            return mcp_server.text_result("Parameter 'question' is required.", True)
        if not current_run:
            return mcp_server.text_result("No active chat request.", True)
        questions.append(task)
        set_activity("waiting")
        return mcp_server.DEFERRED

    if name == "execute_python":
        task.code = str(args.get("code", ""))
        task.description = str(args.get("description", "")).strip()
        if not task.code.strip():
            return mcp_server.text_result("Parameter 'code' is required.", True)
        if not current_run:
            return mcp_server.text_result("No active chat request.", True)
        set_activity("tool_running", tr("running: {}").format(task.description or tr("Code")))
        if prefs and prefs.auto_approve:
            return _run_code_task(task)  # reads the prefs itself
        set_activity("waiting")
        pending.append(task)
        mark_dirty()
        return mcp_server.DEFERRED

    return mcp_server.text_result(f"Unknown tool {name}", True)


# ---------------------------------------------------------------------------
# CLI events (main thread)

TOOL_LABELS = {
    "render_preview": "Looked at a render preview",
    "remember": "Remembered something",
    "save_lesson": "Saved a lesson",
    "get_scene_info": "Looked at the scene",
    "get_viewport_screenshot": "Looked at the viewport",
}


def _handle_event(obj):
    global session_id, streaming_text
    kind = obj.get("type")

    if kind == "stream_event":
        event = obj.get("event") or {}
        etype = event.get("type")
        if etype == "content_block_delta":
            delta = event.get("delta") or {}
            dtype = delta.get("type")
            if dtype == "text_delta":
                streaming_text += delta.get("text", "")
                activity["chars"] += len(delta.get("text", ""))
                mark_dirty()
            elif dtype in ("thinking_delta", "input_json_delta"):
                activity["chars"] += len(delta.get("thinking", "") or delta.get("partial_json", ""))
                mark_dirty()
        elif etype == "content_block_start":
            block = event.get("content_block") or {}
            btype = block.get("type")
            if btype in ("thinking", "redacted_thinking"):
                set_activity("thinking")
            elif btype == "text":
                set_activity("writing")
            elif btype == "tool_use":
                name = block.get("name", "")
                set_activity("tool_call", name.split("__")[-1] if name.startswith("mcp__") else name)
        elif etype == "message_start":
            streaming_text = ""
            set_activity("prompt")
            u = (event.get("message") or {}).get("usage") or {}
            used = sum(int(u.get(k) or 0) for k in
                       ("input_tokens", "cache_read_input_tokens", "cache_creation_input_tokens"))
            if used:
                context["used"] = used

    elif kind == "system" and obj.get("subtype") == "status":
        if obj.get("status") == "compacting":
            set_activity("compacting")
        elif obj.get("compact_result") == "failed":
            add_message("error", tr("Summarizing the chat failed: {}").format(obj.get("compact_error") or ""))
        elif obj.get("compact_result") == "success":
            _last_sent.clear()  # the summary drops details: send the full Blender context again
            _skills_sent.clear()

    elif kind == "system" and obj.get("subtype") == "compact_boundary":
        meta = obj.get("compact_metadata") or {}
        pre, post = int(meta.get("pre_tokens") or 0), int(meta.get("post_tokens") or 0)
        if post:
            context["used"] = post
        add_message("info", tr("Chat summarized ({}k → {}k tokens), older details are condensed.").format(
            round(pre / 1000, 1), round(post / 1000, 1)))

    elif kind == "system" and obj.get("subtype") == "init":
        if activity["kind"] in ("loading", "prompt"):
            set_activity("prompt")  # model is ready, the prompt is being processed
        session_id = obj.get("session_id") or session_id
        for server in obj.get("mcp_servers") or []:
            if server.get("name") == "blender" and server.get("status") != "connected":
                add_message("error", tr("Could not connect to Blender (MCP status: {}).").format(server.get("status")))

    elif kind == "assistant":
        for block in (obj.get("message") or {}).get("content") or []:
            if block.get("type") == "text":
                streaming_text = ""
                add_message("assistant", block.get("text", ""))
            elif block.get("type") == "tool_use":
                tool = block.get("name", "")
                tool = tool.split("__")[-1] if tool.startswith("mcp__") else tool
                if tool in ("ToolSearch", "TodoWrite", "ask_user", "remember", "save_lesson"):
                    continue
                inp = block.get("input") or {}
                if tool == "get_object_info":
                    label = tr("Looked at '{}'").format(inp.get("name", ""))
                elif tool == "execute_python":
                    add_message("tool", inp.get("description") or tr("Ran code"), code=True, tool=tool)
                    continue
                elif tool in _ext_tools:
                    label = _ext_tools[tool].get("label") or tool
                else:
                    label = tr(TOOL_LABELS[tool]) if tool in TOOL_LABELS else tool
                add_message("tool", label, tool=tool)

    elif kind == "user" and not obj.get("isReplay"):
        set_activity("prompt")
        content = (obj.get("message") or {}).get("content")
        if isinstance(content, list):
            for block in content:
                if block.get("type") == "tool_result" and block.get("is_error"):
                    text = block.get("content")
                    if isinstance(text, list):
                        text = " ".join(b.get("text", "") for b in text if isinstance(b, dict))
                    # Code errors and rejections are already shown.
                    if text and "rejected" not in text and "Traceback" not in text:
                        add_message("error", tr("Tool error: {}").format(str(text)[:500]))

    elif kind == "user" and obj.get("isReplay"):
        # The CLI picked up a message sent while Claude was working.
        uid = obj.get("uuid")
        for i, msg in enumerate(queued):
            if msg.get("uid") == uid:
                msg = queued.pop(i)
                msg.pop("uid", None)
                if streaming_text.strip():
                    add_message("assistant", streaming_text)
                    streaming_text = ""
                messages.append(msg)
                mark_dirty()
                break

    elif kind == "rate_limit_event":
        _update_usage(obj.get("rate_limit_info"))

    elif kind == "result":
        session_id = obj.get("session_id") or session_id
        if not compacting:
            _record_stats(obj)
        for info in (obj.get("modelUsage") or {}).values():
            if isinstance(info, dict) and info.get("contextWindow"):
                context["window"] = int(info["contextWindow"])
        if is_local() and lmstudio.status.get("context"):
            context["window"] = lmstudio.status["context"]
        if obj.get("is_error"):
            text = str(obj.get("result") or obj.get("subtype") or tr("Unknown error"))
            if claude_cli.is_auth_error(text):
                _set_login_needed(True)
            add_message("error", text)


def _handle_done(rc, stderr):
    global current_run, streaming_text
    run = current_run
    current_run = None
    if streaming_text.strip():  # cancelled mid-answer: keep what was there
        add_message("assistant", streaming_text)
    streaming_text = ""
    for task in _chat_tasks():
        task.finish(mcp_server.text_result("Request ended.", True))
    _clear_chat_tasks()
    if _followups and not (run and run.cancelled):
        # Messages that arrived while the process was already closing.
        outgoing = list(_followups)
        _followups.clear()
        _start_run(outgoing, get_prefs())
        mark_dirty()
        return
    was_compacting = compacting
    _set_compacting(False)
    set_activity("idle")
    _take_version_word()
    _offer_written_code()
    _empty_temp()
    if run and run.cancelled:
        add_message("info", tr("Stopped"))
        if chat_queue:          # stopped by hand: the queued chats wait
            set_chat_queue_paused(True)
    elif rc == -1 and (stderr or "").startswith("LM Studio"):
        add_message("error", stderr)
    elif rc != 0:
        msg = tr("Claude CLI exited with code {}.").format(rc)
        if stderr:
            msg += "\n" + stderr[-1200:]
        low = (stderr or "").lower()
        if claude_cli.is_auth_error(low):
            _set_login_needed(True)
        if "unknown option" in low:
            msg += "\n" + tr("Tip: update Claude Code with 'claude update' in a terminal.")
            _set_flag("update_needed", True)
        add_message("error", msg)
        if login_needed:
            _login_hint()
    elif rc == 0 and not is_local():
        _set_login_needed(False)
        _set_flag("login_ok", True)
        _set_flag("update_needed", False)
    if rc == 0:
        _chat_works()
    _tidy_names()
    if rc == -1 and (stderr or "").startswith("LM Studio"):
        _set_flag("local_down", True)
    elif rc == 0:
        _set_flag("local_down", False)
    save_current_chat()
    prefs = get_prefs()
    if (rc == 0 and not was_compacting and not (run and run.cancelled) and prefs and prefs.auto_compact
            and context_fraction() >= prefs.compact_at / 100):
        compact(auto=True)
    mark_dirty()


def _empty_temp():
    """After an answer: delete Claude's helper objects (the marked temp collection), one undo step."""
    try:
        from .studio import cadswap
        count = cadswap.empty_temp()
    except Exception:
        traceback.print_exc()
        return
    if count:
        try:
            with blender_tools.viewport_context():
                bpy.ops.ed.undo_push(message="Claude: helper objects removed")
        except Exception:
            pass
        add_message("info", tr("Removed {} helper objects (temp)").format(count))


def _set_flag(name, value):
    globals()[name] = value
    mark_dirty()


def open_update():
    prefs = get_prefs()
    claude_path = claude_cli.find_claude(prefs.claude_path if prefs else "")
    if claude_path:
        claude_cli.open_update(claude_path)
        _set_flag("update_needed", False)


def start_lmstudio():
    """Start LM Studio's server in the background (the next message uses it)."""
    def run():
        try:
            lmstudio._lms("server", "start", timeout=60)
        except Exception as exc:
            print("AI Studio: LM Studio did not start:", exc)
    threading.Thread(target=run, daemon=True).start()
    _set_flag("local_down", False)


def setup_state():
    """What a new user still has to set up (cached for a few seconds, drawn every redraw)."""
    now = time.monotonic()
    if _setup_cache["state"] is not None and now - _setup_cache["time"] < 3.0:
        return _setup_cache["state"]
    prefs = get_prefs()
    cli = claude_cli.find_claude(prefs.claude_path if prefs else "")
    from .studio import core as studio_core, runner as studio_runner, tab_material
    p = studio_runner.prefs()
    state = {
        "cli": cli,
        "login": False if login_needed else (True if login_ok else None),
        "base": tab_material.base_library_file(),
        "output": studio_core.output_root(p.output_root if p is not None else ""),
        "output_set": bool(p is not None and p.output_root),
        "live": bool(prefs and prefs.live_connection),
        "online": online_state(),
    }
    from . import live_clients
    state["live_code"] = live_clients.code_connected()
    state["live_desktop"] = live_clients.desktop_connected() if live_clients.desktop_installed() else None
    _setup_cache.update(time=now, state=state)
    return state


def _tidy_names():
    """After Claude worked in the scene: cameras and lights it named "….001" or with a
    collection prefix get short names ("View_02")."""
    try:
        from .studio import cameras
        cameras.tidy_names()
    except Exception as exc:   # never in the way of the answer
        print("AI Studio: names:", exc)


def _chat_works():
    """The first good answer: the setup's steps are done, the card goes away (its questions
    stay until they were answered)."""
    prefs = get_prefs()
    if prefs is not None and not prefs.setup_done:
        prefs.setup_done = True
        bpy.context.preferences.is_dirty = True
        _setup_cache["state"] = None
        mark_dirty()


def online_state():
    """'ON', 'OFF' (the user can allow it) or 'LOCKED' (Blender started with --offline-mode).
    A fresh Blender starts with online access off until it is allowed once: then Claude Code
    can not be used from the add-on, while LM Studio (local) still works."""
    if bpy.app.online_access:
        return 'ON'
    return 'LOCKED' if bpy.app.online_access_override else 'OFF'


def allow_online():
    """Turn on Preferences › System › Network › Allow Online Access (the user clicked for it)."""
    if bpy.app.online_access_override:
        return False
    bpy.context.preferences.system.use_online_access = True
    bpy.context.preferences.is_dirty = True
    _setup_cache["state"] = None
    mark_dirty()
    return bool(bpy.app.online_access)


def live_status():
    """Text for the chat when another Claude session uses the Live Connection, else ""."""
    if _live_waiting:
        return tr("Cowork waits until this answer is done")
    if any(task.live for task in pending):
        return tr("Cowork wants to run code")
    seen = mcp_server.live_seen[0]
    if seen and time.time() - seen < 20:
        return tr("Cowork connected · last request {} s ago").format(int(time.time() - seen))
    return ""


def _set_login_needed(value):
    global login_needed
    login_needed = value


def _login_hint():
    """Say what to do, and open the login window the first time on its own."""
    global _login_opened
    add_message("info", tr("You are logged out of Claude. Log in with the button below "
                           "(it opens the browser), then send your message again."))
    if not _login_opened:
        _login_opened = True
        open_login()


def open_login():
    global _login_opened
    prefs = get_prefs()
    claude_path = claude_cli.find_claude(prefs.claude_path if prefs else "")
    if not claude_path:
        add_message("error", tr("Claude CLI not found – see the README"))
        return False
    try:
        claude_cli.open_login(claude_path)
    except OSError as exc:
        add_message("error", tr("Could not open the login: {}").format(exc))
        return False
    _login_opened = True   # check often now, so the button goes away right after the login
    _login_since[0] = time.monotonic()
    _login_check["next"] = 0.0
    return True


def check_login():
    """Ask `claude auth status` in a thread; the timer applies the answer (login_needed)."""
    thread = _login_check["thread"]
    if (thread and thread.is_alive()) or is_local():
        return
    prefs = get_prefs()
    claude_path = claude_cli.find_claude(prefs.claude_path if prefs else "")
    if not claude_path:
        return

    def run():
        _login_check["result"] = claude_cli.logged_in(claude_path)

    _login_check["result"] = None
    _login_check["thread"] = threading.Thread(target=run, daemon=True)
    _login_check["thread"].start()


def _poll_login():
    thread = _login_check["thread"]
    if thread and not thread.is_alive():
        _login_check["thread"] = None
        result = _login_check["result"]
        if result is not None and login_needed == result:
            _set_login_needed(not result)
            if result and _login_opened:
                add_message("info", tr("Logged in to Claude."))
            mark_dirty()
        if result:
            _set_flag("login_ok", True)
            _setup_cache["state"] = None
        fast = _login_opened and time.monotonic() - _login_since[0] < LOGIN_FAST
        _login_check["next"] = time.monotonic() + (LOGIN_POLL if fast else 30.0)
    elif login_needed and not thread and time.monotonic() >= _login_check["next"]:
        check_login()


_CODE_FENCE = re.compile(r"```(?:python|py)?[ \t]*\n(.*?)```", re.S)


def _offer_written_code():
    """A local model sometimes writes the code into its answer instead of calling execute_python:
    offer to run it (Run/Reject card), so the turn is not lost."""
    if not is_local() or _turn["code_calls"] or not messages or messages[-1]["role"] != "assistant":
        return
    blocks = [b.strip() for b in _CODE_FENCE.findall(messages[-1]["text"]) if "bpy" in b or "import" in b]
    for code in blocks[:3]:
        task = mcp_server.Task("execute_python", {})
        task.code, task.description = code, tr("Code from the answer (not run by the model)")
        task.from_text = True
        pending.append(task)
    if blocks:
        add_message("info", tr("The model wrote code instead of running it – run it with the card below."))
    mark_dirty()


def _set_compacting(value):
    global compacting
    compacting = value


def compact(auto=False):
    """Summarize the chat (Claude Code's /compact) so it fits the context again."""
    if is_busy() or not session_id:
        return False
    prefs = get_prefs()
    if auto:
        add_message("info", tr("The chat uses {}% of the context – summarizing it…").format(
            round(context_fraction() * 100)))
    _set_compacting(True)
    _start_run([([{"type": "text", "text": COMPACT_COMMAND}], str(uuid.uuid4()))], prefs, single=True)
    if not current_run:
        _set_compacting(False)
        return False
    set_activity("compacting")
    return True


# ---------------------------------------------------------------------------
# Timer

def _tag_redraw():
    wm = bpy.context.window_manager
    if wm is None:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'UI':
                        region.tag_redraw()


_last_second = -1
_last_poll = [0.0, 0]


def _tick():
    global _dirty, _last_second
    try:
        while _prompt_queue:
            text, extra = _prompt_queue.pop(0)
            try:
                _send(text, extra)
            except Exception:
                add_message("error", tr("Sending failed:") + "\n" + traceback.format_exc(limit=3))
        try:
            _next_queued_chat()
        except Exception:
            add_message("error", tr("Sending failed:") + "\n" + traceback.format_exc(limit=3))

        mcp_server.process_tasks(_dispatch)

        for entry in list(_waiting):
            task, check, deadline = entry
            try:
                text = check() if time.monotonic() < deadline else "Stopped waiting (time limit)."
            except Exception as exc:
                text = "Error while waiting: %s" % exc
            if task.cancelled or text is not None:
                _waiting.remove(entry)
                task.finish(mcp_server.text_result(text or "Cancelled."))
                _dirty = True

        # Drop approvals whose request timed out.
        for lst in (pending, questions):
            for task in [t for t in lst if t.done or t.cancelled]:
                lst.remove(task)
                _dirty = True

        while True:
            try:
                item = _events.get_nowait()
            except queue.Empty:
                break
            if item[0] == "event":
                _handle_event(item[1])
            else:
                _handle_done(item[1], item[2])

        for hook in tick_hooks:
            hook()

        _poll_login()

        while _live_waiting and not current_run:
            task = _live_waiting.pop(0)
            if task.cancelled:
                continue
            result = _live_python(task)
            if result is not mcp_server.DEFERRED:
                task.finish(result)
            _dirty = True

        if live_status() and int(time.time()) != _last_poll[1]:   # "last request … ago"
            _last_poll[1] = int(time.time())
            _dirty = True

        if is_local():
            lmstudio.poll_if_due()  # load state and memory for the sidebar
            if lmstudio.live["polled"] != _last_poll[0]:
                _last_poll[0] = lmstudio.live["polled"]
                _dirty = True

        if lmstudio.busy() and int(time.monotonic()) != _last_second:  # loading timer in the sidebar
            _last_second = int(time.monotonic())
            _dirty = True

        if current_run and activity["chars"]:
            _dirty = True  # live token counter

        if current_run and elapsed() != _last_second:  # update the "thinking" timer
            _last_second = elapsed()
            _dirty = True

        if _dirty:
            _dirty = False
            _tag_redraw()
    except Exception:
        traceback.print_exc()
    return TIMER_INTERVAL


# ---------------------------------------------------------------------------
# Display helpers

_MD_PATTERNS = [
    (re.compile(r"\*\*(.+?)\*\*"), r"\1"),
    (re.compile(r"__(.+?)__"), r"\1"),
    (re.compile(r"`{3}[\w-]*"), ""),
    (re.compile(r"`([^`]+)`"), r"\1"),
    (re.compile(r"^#{1,6}\s*", re.M), ""),
    (re.compile(r"^(\s*)[-*] ", re.M), r"\1• "),
]


def plain_text(text):
    for pattern, repl in _MD_PATTERNS:
        text = pattern.sub(repl, text)
    return text


def register():
    load_usage()
    load_chat_queue()
    if chat_queue and not bpy.app.background:
        chat_queue_paused[0] = True     # after a restart the queued chats wait for the user
    crash = autosave.last_crash
    if crash:
        notes.append("Blender did not shut down cleanly last time (probably a crash)"
                     + (f" during: {crash['step']}" if crash.get("step") else "") + ". Be careful with "
                     "heavy operations; the user may have lost recent changes.")
    lmstudio.prefetch()
    prefs = get_prefs()
    if is_local(prefs) and prefs.local_model:
        lmstudio.preload(prefs.local_model, prefs.local_context)
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=0.5, persistent=True)
    if not bpy.app.background:
        _restore_model(default_model())   # Blender starts with a new chat: the default model
    check_login()   # show the Log in button before the first message if Claude is logged out


def unregister():
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)
    if current_run:
        current_run.cancel()
    for task in list(pending):
        task.finish(mcp_server.text_result("Add-on disabled.", True))
    pending.clear()
    save_current_chat()
    mcp_server.stop()


# Moved into their own modules; re-exported so `core.<name>` keeps working.
from .chats import (
    MODEL_KEYS, TITLE_CHARS, TITLE_WORDS, _chat_serial, _restore_model, current_title, default_model,
    delete_chat, list_chats, load_chat, new_chat, rename_chat, save_current_chat, set_current_title,
    short_title
)  # noqa: E402,F401
from .versions import (
    SUMMARY_KINDS, _VERSION_LINE, _fallback_word, _take_version_word, approve, current_version, goto_version,
    summarize, turns, versions
)  # noqa: E402,F401
